var product = [{
    "id": 0,
    "title": "",
    "price": "",
    "description": "",
    "image": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
}, {
    "id": 1,
    "title": "Simple Crokery",
    "price": 2500,
    "description": "Crockery is a broad term that is used to refer to various types of tableware. This would include any type of dishware that is used at the table during mealtime. Crockery can include all forms of dishes such as plates, as well as serving platters, bowls, and dishes that are used to hold condiments, such as a gravy bowl.",
    "image": "ASSETS/IMG/product1.jpg",
}, {
    "id": 2,
    "title": "Utensils Tools",
    "price": 1800,
    "description": "A utensil is a household tool used in the kitchen. Utensils are used to prepare ingredients, cook items, bake foods, or serve dishes. The main purpose of culinary utensils is to conduct a kitchen task, like stirring potatoes or scooping soup",
    "image": "ASSETS/IMG/product6.jpg",
}, {
    "id": 3,
    "title": "Cups Set",
    "price":800,
    "description": "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. It is also used to temporarily replace text in a process called greeking,",
    "image": "ASSETS/IMG/mugs/img8.avif",
}, {
    "id": 4,
    "title": "Ceramics Tool",
    "price":2000,
    "description": "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. It is also used to temporarily replace text in a process called greeking,",
    "image": "ASSETS/IMG/ceramicstool/img18.avif",
}, {
    "id": 6,
    "title": "Kitchen tool",
    "price": 1000,
    "description": "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. It is also used to temporarily replace text in a process called greeking,",
    "image": "ASSETS/IMG/kitchentool/img11.avif ",
}, {
    "id": 7,
    "title": "Cutlery",
    "price":1200,
    "description": "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. It is also used to temporarily replace text in a process called greeking,",
    "image": "ASSETS/IMG/cutlery/img7.avif"},]
// }, {
//     "id": 8,
//     "title": "Realme C35",
//     "price": 32999,
//     "description": "Realme C35 price in Pakistan is Rs. 32,999. Official dealers and warranty providers regulate the retail price of Realme mobile products in official warranty.",
//     "brand": "Realme",
//     "image": "https://www.whatmobile.com.pk/admin/images/Realme/RealmeC35-b.jpg"
// }, {
//     "id": 9,
//     "title": "Tecno Spark 8C 3GB",
//     "price": 20499,
//     "description": "Tecno Spark 8C 3GB price in Pakistan is Rs. 20,499. Official dealers and warranty providers regulate the retail price of Tecno mobile products in official warranty.",
//     "brand": "Tecno",
//     "image": "https://www.whatmobile.com.pk/admin/images/Tecno/TecnoSpark8C3GB-b.jpg"
// }, {
//     "id": 10,
//     "title": "itel Vision 3",
//     "price": 16299,
//     "description": "itel Vision 3 price in Pakistan is Rs. 16,299. Official dealers and warranty providers regulate the retail price of itel mobile products in official warranty.",
//     "brand": "Itel",
//     "image": "https://www.whatmobile.com.pk/admin/images/itel/itelVision3-b.jpg"
// }]