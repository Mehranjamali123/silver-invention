var mugs=[
    {
        img:'ASSETS/IMG/mugs/IMG1',
        title:'Blue and brown Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img2',
        title:'White Ceramics Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img3',
        title:'White Ceramics Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img4',
        title:'White Ceramics Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img5',
        title:'Assorted-color Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img6',
        title:'Assorted-color Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img7',
        title:'Assorted-color Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img8',
        title:'Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img9',
        title:'Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img10',
        title:'Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img11',
        title:'Mugs',
        price:'here',
        btn:'Add to Card',
    },
    {
        img:'ASSETS/IMG/mugs/img12',
        title:'Mugs',
        price:'here',
        btn:'Add to Card',
    },
]